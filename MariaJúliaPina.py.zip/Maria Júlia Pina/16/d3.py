i = 1
while i != 0:
    i = int(input("Digite um número aleatório: "))