a = int(input("Digite um número inteiro: "))
b = int(input("Digite outro número inteiro: "))

i = a + 1
while i<b:
    print(i)
    i = i + 1