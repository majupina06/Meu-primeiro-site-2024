a = 0
c = 140
b = 145

while c <= b:
    a = a + 1
    c = c + 2.1
    b = b + 1.1
    print("ser ão necessários", a, "anos")