n = int(input("Digite um número: "))

i = 0
while i <= 10:
    resultado = n * i+1
    print(n, "*", i, "=", (n * i))
    i = i + 1