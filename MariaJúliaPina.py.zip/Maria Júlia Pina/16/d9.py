i = 1
while i <= 10:
    j = 1
    while j <= 10:
        resultado = i * j
        print(i, "x", j, "=", resultado)
        j = j + 1
    print()
    i=i+1




