i = 1
while i <= 4000:
    print("Olá")
    i = i + 1
