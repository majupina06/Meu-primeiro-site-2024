for numero in range(1,11+1):
    print(numero)