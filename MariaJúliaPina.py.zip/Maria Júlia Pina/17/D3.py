nomes = ['Ana', 'Bruno', 'Maria']
for nome in nomes:
    print(f'Olá, {nome}!')
