a = int(input("Digite um número: "))
b = int(input("Digite outro número: "))


for impar in range(a, b ):
    if impar % 2 != 0:
        print(impar)