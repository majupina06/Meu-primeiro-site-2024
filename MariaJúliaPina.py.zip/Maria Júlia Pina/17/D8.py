for par in range(10):
    if par % 2 == 0:
        print(par)