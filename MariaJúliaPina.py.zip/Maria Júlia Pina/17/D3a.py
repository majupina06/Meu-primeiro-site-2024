nomes = ['Ana', 'Bruno', 'Carlos']
for nome in nomes:
    print(nomes[1])
    break