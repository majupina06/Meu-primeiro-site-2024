nome = "Juliano"
for caractere in nome:
    print(f"O caractere é: {caractere}")

    dentro do [] fica inteiro, fora fica em formato de caractere