for numero in range (0, 11, 1):
    print(numero)