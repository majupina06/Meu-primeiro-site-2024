valores = [10, 20, 30]
for valor in valores:
    print(f"O valor é: {valor}")
    