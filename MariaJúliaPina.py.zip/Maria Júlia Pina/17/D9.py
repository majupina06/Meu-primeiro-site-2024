for numero in range (10, 0, -1):
    print(numero)