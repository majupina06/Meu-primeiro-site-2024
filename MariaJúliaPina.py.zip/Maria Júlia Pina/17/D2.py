Listafrutas = ['maça', 'banana', 'cereja']
for fruta in Listafrutas:
    print(fruta)