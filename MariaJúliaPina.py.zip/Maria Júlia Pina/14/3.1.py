id = int(input("Digite seu id: "))
nome = str(input("Digite seu nome: "))
salário = float(input("Digite o valor do seu salário: "))
nacionalidade = bool(input("Sua nacionalidade é brasileira?: "))

print(f"Seu ID é {id}, com nome de {nome}. Sua nacionalidade é brasileira?  {nacionalidade}. Seu salário é {salário}")