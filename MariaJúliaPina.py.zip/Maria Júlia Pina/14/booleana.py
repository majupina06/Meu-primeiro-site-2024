tbool = True
#criamos uma variavel tipo bool
print()