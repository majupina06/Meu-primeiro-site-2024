nome = input("Digite seu nome: ")
idade = input("Digite sua idade: ")
telefone = input("Digite seu telefone: ")
print(f"{nome} tem {idade} anos e seu telefone é {telefone}")