n1 = float(input("Digite um número real: "))
n2 = float(input("Digite outro número real: "))

soma = n1 + n2
subtração = n1 - n2
multiplicação = n1 * n2
divisão = n1 / n2

print(f"A soma dos dois números reais é igual a: {soma}")
print(f"A subtração dos dois números é igual a: {subtração}")
print(f"A multiplicação entre os dois números é igual a {multiplicação}")
print(f"A divisão entre os dois números reais é igual a {divisão}")