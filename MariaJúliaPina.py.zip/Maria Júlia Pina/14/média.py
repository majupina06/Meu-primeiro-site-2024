dec1 = float(input("Digite um número decimal: "))
dec2 = float(input("Digite outro número decimal: "))
dec3 = float(input("Digite mais um número decimal: "))

soma = dec1 + dec2 + dec3
media = soma / 3

print(f"{media} é o resultado da média dos três números")