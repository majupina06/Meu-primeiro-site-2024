n1 = float(input("Digite um número: "))
p1 = float(input("Digite um número: "))
n2 = float(input("Digite um número: "))
p2 = float(input("Digite um número: "))
n3 = float(input("Digite um número: "))
p3 = float(input("Digite um número: "))

media = (n1*p1+n2*p1+n3*p3) / (p1+p2+p3)

print("A média ponderada dos números é igual a: ", media)