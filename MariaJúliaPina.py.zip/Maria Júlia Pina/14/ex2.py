salario = float(input("Digite seu salário: "))

multip = (salario * 0.25) + salario

print(f"O total do seu aumento será: ", multip)

