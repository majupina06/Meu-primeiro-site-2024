print("Maria Júlia")
print(f"A idade é: {18}")
print(f"O salário é {1518.15: .2f}")
print("A nacionalidade é: Brasileira")
