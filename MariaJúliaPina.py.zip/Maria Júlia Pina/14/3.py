idade = 0
altura = 0.0
nome = " "

idade = int(input("Digite sua idade: "))
altura = float(input("Digite sua altura: "))
nome = str(input("Digite seu nome: "))

print(f"{nome} tem {idade} anos e {altura} de altura")