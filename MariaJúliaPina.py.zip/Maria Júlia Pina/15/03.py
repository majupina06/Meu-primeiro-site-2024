nota = float(input("Digite a nota do aluno: "))

if nota >= 7:
    print(f"O aluno está aprovado")
else:
    print(f"O aluno está reprovado")