nota = float(input("Digite a nota do aluno: "))
frequencia = float(input("Digite a porcentagem da frequência do aluno: "))

if nota >= 7 and frequencia >= 70:
    print(f"O aluno está aprovado")

