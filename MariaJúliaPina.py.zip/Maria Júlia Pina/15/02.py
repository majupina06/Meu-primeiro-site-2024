nota = float(input("Digite sua nota: "))

if nota < 7 and nota >= 4:
    print(f"Tem direito a exame de recuperação")