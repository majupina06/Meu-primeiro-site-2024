v1 = float(input("Digite um valor: "))
v2 = float(input("Digite outro valor: "))

if v1 > v2:
    print(f"O primeiro valor é maior")
if v1 < v2:
    print(f"O primeiro valor é menor")
if v1 == v2:
    print(f"Os valores são iguais")