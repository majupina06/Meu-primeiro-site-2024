numero = float(input("Digite um número de 1 a 7: "))

if numero == 1:
    print(f"Domingo")
elif numero == 2:
    print(f"Segunda-feira")
elif numero == 3:
    print(f"Terça-feira")
elif numero == 4:
    print(f"Quarta-feira")
elif numero == 5:
    print(f"Quinta-feira")
elif numero == 6:
    print(f"Sexta-feira")
elif numero == 7:
    print(f"Sábado")
else:
    print(f"Número inválido")
